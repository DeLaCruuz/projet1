#include "struct.h"
int obtenirGagnant(Joueur joueurs[], int nb_joueurs) {
    int scoreMax = joueurs[0].score;
    int indiceGagnant = 0;
    for (int i = 1; i < nb_joueurs; i++) {
        if (joueurs[i].score > scoreMax) {
            scoreMax = joueurs[i].score;
            indiceGagnant = i;
        }
    }
    return indiceGagnant;
}
void mettreAJourScores(Joueur joueurs[], int joueurCourant, int nbrcoup, int deplacementsrobots, int r, int nb_joueurs){
    if (nbrcoup < deplacementsrobots) {
        // Le joueur courant ne marque aucun point, les autres marquent 1 point chacun
        printf("Le robot a atteint sa cible bien trop lentement le tout le monde marque donc un point sauf le joueur qui viens de jouer\n");
        for (int i = 0; i <  nb_joueurs; i++) {
            if (i != r) {
                joueurs[i].score += 1;
            }
        }
    }

                else if (nbrcoup == deplacementsrobots) {
                    printf("Le robot a atteint sa cible comme il était prévu, le joueur venant de jouer marque donc 2 points\n");
                    // Le joueur courant marque 2 points
                    joueurs[r].score += 2;
                }
                    else if(nbrcoup > deplacementsrobots){
                        printf("le robot a ateint sa cible plus rapidement que prévu, donc le joueur qui viens de jouer perd 1 point\n");
                    // Le joueur courant perd 1 point
                    joueurs[joueurCourant].score -= 1;
                }
}

void afficherScores(Joueur joueurs[], int nb_joueur) {
    printf("Scores :\n");
    for (int i = 0; i < nb_joueur; i++) {
        printf("Joueur %s : %d points\n", joueurs[i].nom, joueurs[i].score);
    }
    int indiceGagnant = obtenirGagnant(joueurs, nb_joueur);
    printf("Gagnant : %s avec %d points\n", joueurs[indiceGagnant].nom, joueurs[indiceGagnant].score);
}
