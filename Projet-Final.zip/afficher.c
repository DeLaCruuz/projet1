#include "struct.h"
void afficherMurs(int rangees, int colonnes) {
    for (int i = 0; i <= rangees; i++) { // <= pour inclure la nouvelle dimension
        for (int j = 0; j <= colonnes; j++) { // <= pour inclure la nouvelle dimension
            if (grille[i][j] == '#' || grille[i][j] == '*' || grille[i][j] == '@' || grille[i][j] == '+' || grille[i][j] == '|') {
                couleur("31");
                printf("■ ");
                couleur("0");
            } else if (grille[i][j] >= 'A' && grille[i][j] <= 'R') {
                couleur("34");
                printf("%c ", grille[i][j]);
                couleur("0");
            } else if (grille[i][j] == 'r') {
                printf("🐧");
            } else if (grille[i][j] == 'x') {
                printf("🐶");
            } else if (grille[i][j] == 'y') {
                printf("🐱");
            } else if (grille[i][j] == 'z') {
                printf("🐴");
            } else if (grille[i][j] == '-') {
                couleur("32");
                printf("- ");
                couleur("0");
            } else {
                printf("%c ", grille[i][j]);
            }
        }
        printf("\n");
    }
}

Resultat  affichageElements(Robot robots[], Joueur joueurs[], int joueurCourant, int manche, int rangees, int colonnes) {
   int res = 0;
   int premiere_manche = 0;
   static int nb_joueur = 0;


       if(manche==0) {
           do{
           printf("Nombre de joueurs : ");
           res = scanf("%d", &nb_joueur);
           if (nb_joueur < 2 || res != 1) {
               printf("Erreur veuillez saisir un chiffre ou nombre superieur à 2.\n");
           }
               while (getchar() != '\n');

       } 
               while (nb_joueur < 2 || res != 1);

       for (int i = 0; i < nb_joueur; i++) {
           printf("Entrez le nom du Joueur %d : ", i + 1);
           scanf("%s", joueurs[i].nom);
           for (int j = 0; j < i; j++) {
               if (strcmp(joueurs[j].nom, joueurs[i].nom) == 0) {
                   printf("Erreur: Ce nom est déjà utilisé par un autre joueur. Veuillez choisir un autre nom.\n");
                   i--;
                   j = i;
                   break;
               }
           }
           joueurs[i].score = 0;
       }

      premiere_manche ++;
           //printf("NOMBRE DE LA PREMIERE MANCHE :%d", premiere_manche);

   }//while(premiere_manche == 0);
printf("\n\nRES = %d\n\n", nb_joueur);

   for (int i = 0; i < nb_joueur; i++) {
       printf("Voici le robot pour le Joueur %s : \n", joueurs[i].nom);
       if (nb_joueur >= 1) {
           switch (i % nb_joueur) {
               case 0: printf("🐧\n"); break;
               case 1: printf("🐶\n"); break;
               case 2: printf("🐱\n"); break;
               case 3: printf("🐴\n"); break;
               default: printf("Erreur dans la sélection du robot\n"); exit(EXIT_FAILURE);
           }
       }
   }

   int niveau;
    printf("Quel niveau de difficulté souhaitez-vous ?\n");
    printf("Entrez \n1 pour facile\n2 pour moyen\n3 pour difficile\n\nAllez-y :");

    res = scanf("%d", &niveau);
    if (res != 1) { // Utiliser la variable res pour vérifier la validité de la saisie
         printf("L'entrée n'est pas valide.\n");
         printf("Veuillez réessayer.\n");
         // Vider le buffer pour éviter une boucle infinie en cas d'entrée non valide
         while (getchar() != '\n');
         exit(EXIT_FAILURE);
     }
     switch (niveau) {
         case 1:
             printf("Très bien, allons-y pour le niveau facile\n");
             creationMinuteur(15);
             break;
         case 2:
             printf("Très bien, allons-y pour le niveau moyen\n");
             creationMinuteur(10);
             break;
         case 3:
             printf("Très bien, allons-y pour le niveau difficile\n");
             printf("Grille avec les cibles et les robots :\n");
             afficherMurs(rangees, colonnes);
             creationMinuteur(5);
             break;
         default:
             printf("L'entrée n'est pas valide.\n");
             printf("Veuillez réessayer.\n");
             // Vider le buffer pour éviter une boucle infinie en cas d'entrée non valide
             while (getchar() != '\n');
             exit(EXIT_FAILURE);
     }
    printf("\033[H\033[J");
   int r = 0;

   for (int i = 0; i < nb_joueur; i++) {
       do{
         printf("%s : entre ton nombre de coups : ", joueurs[i].nom);
        res = scanf("%d", &joueurs[i].nbrcoup);
           if(res != 1 || joueurs[i].nbrcoup < 1){
                printf("Erreur veuillez saisir un nombre superieur ou égale à 1 \n");
                    }
           while (getchar() != '\n');
       }while(res != 1 || joueurs[i].nbrcoup < 1);
         if (joueurs[i].nbrcoup < joueurs[r].nbrcoup) {
             r = i;
         }
     }


   printf("Le joueur ayant le moins de coups (%d) commence.\n", joueurs[r].nbrcoup);
    printf("Voici le robot pour le Joueur %s : ", joueurs[r].nom);
    if (nb_joueur >= 1) {
        switch (r) {
            case 0:
                printf("🐧\n");
                break;
            case 1:
                printf("🐶\n");
                break;
            case 2:
                printf("🐱\n");
                break;
            case 3:
                printf("🐴\n");
                break;
            default:
                printf("Erreur dans la sélection du robot\n");
                exit(EXIT_FAILURE);


         }
        }

   afficherMurs(rangees, colonnes);


   Resultat resultat = {r, joueurs[r].nbrcoup, nb_joueur};
   return resultat;
}

char affichageCible(char c) {

    c = rand() % NB_CIBLES + 'A';
    printf("Voici la cible que vous devez atteindre : %c \n\n", c);

    printf("Bonne chance ;)\n\n");
    return c; // Ajouter cette ligne pour retourner la valeur de la cible
}