#include "struct.h"


void creationMinuteur(int chrono){
  printf("Temps de réflexion : %d secondes\n", chrono);

for (int i = chrono; i>0; i--){
  sleep(1);
}
 printf("Temps de réflexion terminé \n");
}   


void creationMinuteur(int chrono);
