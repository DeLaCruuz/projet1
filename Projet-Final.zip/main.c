#include "struct.h"
#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <unistd.h> // For sleep

#define MAX_RANGEES 40
#define MAX_COLONNES 40
#define NB_CIBLES 18
#define couleur(param) printf("\033[%sm", param)



int main() {
    int nbManches, joueurCourant, deplacementsCourants, nb_joueur;
    int deplacementsrobots = 0;
    Joueur joueurs[nb_joueur];
    int res;
    Resultat resultat;
  

    do {
        printf("Entrez le nombre de manches : ");
    res = scanf("%d", &nbManches);
    if (nbManches < 1 || res != 1) {
        printf("Erreur veuillez saisir un chiffre ou un nombre superieur à 1.\n");
       while (getchar() != '\n');
    }
       } while(nbManches < 1 || res != 1);

    for (int manche = 0; manche < nbManches; manche++) {
        printf("\n=== Manche %d ===\n", manche + 1);

        int rangees = rand() % 6 + 25;
        int colonnes = rand() % 6 + 25;

        initialiserGrille(rangees, colonnes);
        Cible cibles[NB_CIBLES];
        placerCibles(cibles);
        Robot robots[NB_ROBOTS];
        placerRobots(robots);


        char c = affichageCible(c);
        Resultat resultat = affichageElements(robots, joueurs, joueurCourant, manche, rangees, colonnes);

        int r = resultat.joueurIndex;
        int nbrcoup = resultat.nbrcoup;
        int nb_joueur = resultat.nb_joueur;

        deplacementsrobots = deplacerRobot(r, c, robots, cibles, deplacementsrobots);
        mettreAJourScores(joueurs, joueurCourant, nbrcoup, deplacementsrobots, r, nb_joueur);
        afficherScores(joueurs, nb_joueur);
    }






    return 0;
}