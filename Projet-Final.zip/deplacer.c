#include "struct.h"
int deplacerRobot(int r, char c, Robot robots[], Cible cibles[], int deplacementsrobots) {
    char direction;
    bool atteintCible = false;


    while (!atteintCible) {
        printf("Entrez la direction pour déplacer le robot %d (Z = haut, S = bas, Q = gauche, D = droite) : ", r + 1);
        scanf(" %c", &direction);

        if (direction != 'Z' && direction != 'z' &&
            direction != 'Q' && direction != 'q' &&
            direction != 'S' && direction != 's' &&
            direction != 'D' && direction != 'd') {
            printf("Direction invalide. Veuillez entrer Z, Q, S ou D.\n");
            continue;
        }
         deplacementsrobots += 1;

        while (true) {
            int newX = robots[r].position.x;
            int newY = robots[r].position.y;

            switch (direction) {
                case 'Z':
                case 'z':
                    newX -= 1;
                    break;
                case 'S':
                case 's':
                    newX += 1;
                    break;
                case 'Q':
                case 'q':
                    newY -= 1;
                    break;
                case 'D':
                case 'd':
                    newY += 1;
                    break;
                default:
                    printf("Commande de direction non valide veuillez recommencer.\n");
            }

            if (newX < 0 || newX > MAX_RANGEES || newY < 0 || newY > MAX_COLONNES ||
                grille[newX][newY] == '#' || grille[newX][newY] == '*' || grille[newX][newY] == '+' ||
                grille[newX][newY] == '@' || grille[newX][newY] == '|' ||
                (grille[newX][newY] >= 'r' && grille[newX][newY] <= 'z')) {
                printf("Obstacle rencontré. Veuillez choisir une nouvelle direction.\n");
                printf("Nombre de coup : %d\n\n", deplacementsrobots);
                break;
            }

            grille[robots[r].position.x][robots[r].position.y] = '-';
            robots[r].position.x = newX;
            robots[r].position.y = newY;
            grille[newX][newY] = robots[r].symbole;

            // Affichage des coordonnées pour le débogage
            printf("Nouvelles coordonnées du robot : (%d, %d)\n", newX, newY);
            printf("Coordonnées de la cible : (%d, %d)\n", cibles[c - 'A'].position.x, cibles[c - 'A'].position.y);

            afficherMurs(MAX_RANGEES, MAX_COLONNES);
            //sleep(1);

            // Vérification si le robot atteint la cible
            if (newX == cibles[c - 'A'].position.x && newY == cibles[c - 'A'].position.y) {
                printf("Vous avez atteint la cible !\n");
                atteintCible = true;
                break;
            }

        }

    }
    return deplacementsrobots;
}