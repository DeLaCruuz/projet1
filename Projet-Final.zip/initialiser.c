#include "struct.h"
void initialiserGrille(int rangees, int colonnes) {
    // Initialisation de la grille avec des murs sur les bords
    for (int i = 0; i <= rangees; i++) { // <= pour inclure la nouvelle dimension
        for (int j = 0; j <= colonnes; j++) { // <= pour inclure la nouvelle dimension
            if (i == 0 || i == rangees || j == 0 || j == colonnes) {
                grille[i][j] = '#'; // Caractère pour les murs
            } else {
                grille[i][j] = '-'; // Caractère pour l'intérieur de la grille
            }
        }
    }

    int row1, row2, col1, col2;

    // Murs horizontaux
    do {
        row1 = rand() % (rangees - 3) + 2; // Exclut les bords de la grille et une marge pour les murs
        row2 = rand() % (rangees - 3) + 2; // Exclut les bords de la grille et une marge pour les murs
    } while (abs(row1 - row2) <= 2);

    grille[row1][1] = '*';
    grille[row1][colonnes - 1] = '*';
    grille[row2][1] = '*';
    grille[row2][colonnes - 1] = '*';

    // Murs verticaux
    do {
        col1 = rand() % (colonnes - 3) + 2; // Exclut les bords de la grille et une marge pour les murs
        col2 = rand() % (colonnes - 3) + 2; // Exclut les bords de la grille et une marge pour les murs
    } while (abs(col1 - col2) <= 2);

    grille[1][col1] = '*';
    grille[rangees - 1][col1] = '*';
    grille[1][col2] = '*';
    grille[rangees - 1][col2] = '*';
}











