#ifndef STRUCT_H
#define STRUCT_H
#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <unistd.h> // For sleep

#define MAX_RANGEES 40
#define MAX_COLONNES 40
#define NB_CIBLES 18
#define NB_ROBOTS 4
#define couleur(param) printf("\033[%sm", param)
#define MAX_JOUEURS 10
// Structure pour stocker les coordonnées d'une position sur la grille
typedef struct {
    int x;
    int y;
} Position;

typedef struct {
    int joueurIndex;
    int nbrcoup;
    int nb_joueur;
} Resultat;

// Structure pour représenter une cible sur la grille
typedef struct {
    char symbole;
    Position position;
    int numero;
    Position cibleFinale;
} Cible;

// Structure pour représenter un robot sur la grille
typedef struct {
    char symbole;
    Position position;
    char couleur;
    int chiffre;
} Robot;


typedef struct {
    char nom[50];
    int score;
    int nbrcoup;
} Joueur;

void creationMinuteur(int chrono);
void mettreAJourScores(Joueur joueurs[], int joueurCourant, int nbrcoup, int deplacementsrobots, int r, int nb_joueurs);
int obtenirGagnant(Joueur joueurs[], int nb_joueurs);
void afficherScores(Joueur joueurs[], int nb_joueur);
void initialiserGrille(int rangees, int colonnes);
void placerCibles(Cible cibles[]);
void placerRobots(Robot robots[]);
void afficherMurs(int rangees, int colonnes);
Resultat  affichageElements(Robot robots[], Joueur joueurs[], int joueurCourant, int manche, int rangees, int colonnes);
char affichageCible(char c);
int deplacerRobot(int r, char c, Robot robots[], Cible cibles[], int deplacementsrobots);
char grille[MAX_RANGEES + 1][MAX_COLONNES + 1]; // Ligne modifiée

  

#endif