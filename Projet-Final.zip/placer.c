#include "struct.h"
void placerCibles(Cible cibles[]) {
    for (int i = 0; i < NB_CIBLES; i++) {
        int x, y;
        int positionValide;
        do {
            x = rand() % (MAX_RANGEES - 4) + 2;  // Exclut les bords de la grille et une marge pour les murs
            y = rand() % (MAX_COLONNES - 4) + 2;  // Exclut les bords de la grille et une marge pour les murs
            positionValide = 1;

            // Vérifie que toutes les cases dans un rayon de deux cases autour de la position choisie sont libres
            for (int dx = -2; dx <= 2; dx++) {
                for (int dy = -2; dy <= 2; dy++) {
                    if (grille[x + dx][y + dy] != '-') {
                        positionValide = 0;
                        break;
                    }
                }
                if (!positionValide) {
                    break;
                }
            }
        } while (!positionValide);

        int angleAleatoire = rand() % 4; // Génère un nombre aléatoire entre 0 et 3

        if (angleAleatoire == 0) {
            // Place l'angle inférieur droit
            grille[x + 1][y + 1] = '@'; // Angle inférieur droit
            grille[x][y + 1] = '|';     // Mur à droite
            grille[x + 1][y] = '+';     // Mur en bas
        } else if (angleAleatoire == 1) {
            // Place l'angle inférieur gauche
            grille[x - 1][y + 1] = '@'; // Angle inférieur gauche
            grille[x][y + 1] = '|';     // Mur à droite
            grille[x - 1][y] = '+';     // Mur en bas
        } else if (angleAleatoire == 2) {
            // Place l'angle supérieur droit
            grille[x + 1][y - 1] = '@'; // Angle supérieur droit
            grille[x][y - 1] = '|';     // Mur à gauche
            grille[x + 1][y] = '+';     // Mur en haut
        } else if (angleAleatoire == 3) {
            // Place l'angle supérieur gauche
            grille[x - 1][y - 1] = '@'; // Angle supérieur gauche
            grille[x][y - 1] = '|';     // Mur à gauche
            grille[x - 1][y] = '+';     // Mur en haut
        }

        grille[x][y] = 'A' + i; // Utilisation de caractères alphabétiques pour les cibles
        cibles[i].symbole = 'A' + i; // Stocker le symbole de la cible
        cibles[i].numero = i + 1;
        cibles[i].position.x = x;
        cibles[i].position.y = y;
    }
}

void placerRobots(Robot robots[]) {
    char symboles[] = {'r', 'x', 'y', 'z'}; // Symboles pour les robots

    for (int i = 0; i < NB_ROBOTS; i++) {
        int x, y;

        // Cherche une position vide
        do {
            x = rand() % (MAX_RANGEES + 1); // Inclut la nouvelle dimension
            y = rand() % (MAX_COLONNES + 1); // Inclut la nouvelle dimension
        } while (grille[x][y] != '-' || grille[x - 1][y] != '-' || grille[x + 1][y] != '-' || grille[x][y - 1] != '-' || grille[x][y + 1] != '-');

        // Place le robot sur la grille
        grille[x][y] = symboles[i]; // Symbole pour le robot
        robots[i].symbole = symboles[i];
        robots[i].position.x = x;
        robots[i].position.y = y;
    }
}